---
title: CoherentAI Document Registry
slug: coherentai-document-registry
document_type: registry
document_scope: kernel
document_status: active
authority_level: structural
canonical: true
version: 2.0
last_reviewed: 2026-03-14
related_system: coherentai
source_bucket: codex-vault
source_folder: system-kernel
summary: |
  Complete document registry for CoherentAI v2.0. Defines all 52 known
  documents across field canon, pillar canon, system kernel, measures kernel,
  and role contracts — with slug, path, doc_class, binding_strength, pillar,
  bucket/folder, and status. This is the authoritative index CoherentAI uses
  for document classification, routing, and storage decisions.
---

# CoherentAI Document Registry v2.0

## Binding Strength Scale

| Value | Meaning |
|---|---|
| `critical` | Foundational. Cannot be overridden. Changes require full canon challenge. |
| `high` | Binding architecture. Governs implementation decisions. |
| `medium_high` | Strong guidance. Deviation requires documented reason. |
| `medium` | Operational reference. May be updated through normal process. |
| `low` | Draft, progress, or informational. Not binding. |

---

# SECTION 1 — Field Canon
bucket: codex-vault / folder: field-canon

  - slug: canon-registry
    path: src/canon/registry.md
    doc_class: registry
    binding_strength: critical
    pillar: c3
    status: active
    summary: Registers and orders the 13 field-level canon records.

  - slug: c3-community-partners-dao-llc
    path: src/canon/codexstone/c3-community-partners-dao-llc.md
    doc_class: field_canon
    binding_strength: critical
    pillar: c3
    status: active

  - slug: codexstone-geometric-logic
    path: src/canon/codexstone/codexstone-geometric-logic.md
    doc_class: field_canon
    binding_strength: critical
    pillar: c3
    status: active

  - slug: recognition-as-protocol-whitepaper
    path: src/canon/codexstone/recognition-as-protocol-whitepaper.md
    doc_class: field_canon
    binding_strength: high
    pillar: c3
    status: active
    note: Slug corrected from wave-two-recognition-as-protocol.

  - slug: c3-model
    path: src/canon/connect/c3-model.md
    doc_class: field_canon
    binding_strength: critical
    pillar: c3
    status: active

  - slug: field-emergence-whitepaper
    path: src/canon/connect/field-emergence-whitepaper.md
    doc_class: field_canon
    binding_strength: high
    pillar: c3
    status: active

  - slug: founders-note-canon
    path: src/canon/connect/founders-note-canon.md
    doc_class: field_canon
    binding_strength: high
    pillar: c3
    status: active

  - slug: field-canon-pillar-canon-inheritance
    path: src/canon/contribute/field-canon-pillar-canon-inheritance.md
    doc_class: field_canon
    binding_strength: critical
    pillar: c3
    status: active

  - slug: foundational-concept-seeds
    path: src/canon/contribute/foundational-concept-seeds.md
    doc_class: field_canon
    binding_strength: high
    pillar: c3
    status: active

  - slug: interoperability-rules
    path: src/canon/contribute/interoperability-rules.md
    doc_class: field_canon
    binding_strength: critical
    pillar: c3
    status: active

  - slug: coherent-convergence-whitepaper
    path: src/canon/create/coherent-convergence-whitepaper.md
    doc_class: field_canon
    binding_strength: high
    pillar: c3
    status: active

  - slug: measures-thesis
    path: src/canon/create/measures_thesis.md
    doc_class: field_canon
    binding_strength: critical
    pillar: measures
    status: active

  - slug: measures-installation-model
    path: src/canon/create/measures-installation-model.md
    doc_class: field_canon
    binding_strength: critical
    pillar: measures
    status: active

  - slug: coherent-convergence-packet-v1
    path: canon-final/field-canon/Coherent-Convergence-Packet_v1.md
    doc_class: field_canon
    binding_strength: high
    pillar: c3
    status: active
    summary: Formalizes transition into coherent convergence. February 17, 2026 integration marker.

  - slug: c3-model-circuit-spec
    path: canon-final/field-canon/Priceless_Gallery_Initiative.md
    doc_class: field_canon
    binding_strength: critical
    pillar: c3-model
    status: active
    summary: Defines Connect · Contribute · Create circuits and 33/33/33 split.

---

# SECTION 2 — Pillar Canon
bucket: codex-vault / folder: pillar-canon

  - slug: measures-of-inanna-pillar-meta
    path: canon-final/pillar-canon/measures-of-inanna-meta.md
    doc_class: pillar_meta
    binding_strength: critical
    pillar: measures
    status: active

  - slug: priceless-gallery-pillar-meta
    path: canon-final/pillar-canon/priceless-gallery-meta.md
    doc_class: pillar_meta
    binding_strength: critical
    pillar: gallery
    status: active

  - slug: c3-model-pillar-meta
    path: canon-final/pillar-canon/c3-model-meta.md
    doc_class: pillar_meta
    binding_strength: critical
    pillar: c3-model
    status: active

  - slug: c3-community-partners-dao-llc-pillar-meta
    path: canon-final/pillar-canon/c3-community-partners-dao-llc-meta.md
    doc_class: pillar_meta
    binding_strength: critical
    pillar: restore
    status: active

  - slug: marble-mes-canon
    path: canon-final/pillar-canon/Marble_MEs_Canon.md
    doc_class: canon
    binding_strength: critical
    pillar: measures
    status: active
    summary: Defines the Thirteen Marble MEs as governance primitives.

  - slug: marble-pillar-authority-context
    path: canon-final/pillar-canon/Marble_Pillar_Authority_Context.md
    doc_class: canon
    binding_strength: high
    pillar: measures
    status: active
    summary: Mesopotamian authority context. Authority as transmission, not ownership.

  - slug: obsidian-measure-of-reduction
    path: canon-final/pillar-canon/Obsidian_Measure_of_Reduction.md
    doc_class: canon
    binding_strength: high
    pillar: measures
    status: active
    summary: Defines the Obsidian pillar as descent as a measured process.

  - slug: crystal-measure-of-recognition
    path: canon-final/pillar-canon/Crystal_Measure_of_Recognition.md
    doc_class: canon
    binding_strength: high
    pillar: measures
    status: active
    summary: Defines the Crystal pillar as recognition as structural clarification.

  - slug: measures-of-inanna-exhibition
    path: canon-final/pillar-canon/Measures_impact.md
    doc_class: canon
    binding_strength: high
    pillar: measures
    status: active
    summary: Exhibition in three movements. The measure holds with or without witness.

  - slug: mes-function-c3-governance
    path: canon-final/pillar-canon/MEs_Function_c3_governance.md
    doc_class: canon
    binding_strength: high
    pillar: measures
    status: active
    summary: Maps the 13 MEs to c3 architecture layers across four seasonal phases.

  - slug: measures-phase-release-calendar
    path: canon-final/pillar-canon/Measures_Phase_Release.md
    doc_class: canon
    binding_strength: critical
    pillar: measures
    status: active
    event_required: true
    summary: Full phased release calendar anchored to astronomical markers.

---

# SECTION 3 — System Kernel
bucket: codex-vault / folder: system-kernel

  - slug: coherentai-kernel-overview
    path: canon-final/system-kernel/00_kernel_overview.md
    doc_class: doctrine
    binding_strength: critical
    pillar: coherentai
    status: active

  - slug: coherentai-system-map
    path: canon-final/system-kernel/COHERENTAI_SYSTEM_MAP.md
    doc_class: doctrine
    binding_strength: critical
    pillar: coherentai
    status: active

  - slug: nine-guardrails
    path: canon-final/system-kernel/11_guardrails_9.md
    doc_class: canon
    binding_strength: critical
    pillar: coherentai
    status: active

  - slug: coherentai-role-charter
    path: canon-final/system-kernel/03_rolecharter.md
    doc_class: architecture
    binding_strength: critical
    pillar: coherentai
    status: active

  - slug: coherentai-verification-rules
    path: canon-final/system-kernel/05_verification_rules.md
    doc_class: architecture
    binding_strength: high
    pillar: coherentai
    status: active
    event_required: true

  - slug: coherentai-change-control
    path: canon-final/system-kernel/05_change_control.md
    doc_class: protocol
    binding_strength: high
    pillar: coherentai
    status: active
    event_required: true

  - slug: coherentai-oar-logging-spec
    path: canon-final/system-kernel/06_oar_logging_spec.md
    doc_class: architecture
    binding_strength: high
    pillar: coherentai
    status: active

  - slug: coherentai-result-layer-spec
    path: canon-final/system-kernel/07_result_layer.md
    doc_class: architecture
    binding_strength: high
    pillar: coherentai
    status: active

  - slug: coherentai-dispatcher-spec
    path: canon-final/system-kernel/02_dispatcher_spec.md
    doc_class: architecture
    binding_strength: high
    pillar: coherentai
    status: draft

  - slug: coherentai-llm-execution-engine-spec
    path: canon-final/system-kernel/04_llm_execution_engine_spec.md
    doc_class: architecture
    binding_strength: high
    pillar: coherentai
    status: draft

  - slug: coherentai-installation-protocol
    path: canon-final/system-kernel/COHERENTAI_INSTALLATION_PROTOCOL.md
    doc_class: protocol
    binding_strength: high
    pillar: coherentai
    status: active

  - slug: coherentai-document-classification-function
    path: canon-final/system-kernel/COHERENTAI_DOCUMENT_CLASSIFICATION_FUNCTION.md
    doc_class: architecture
    binding_strength: high
    pillar: coherentai
    status: active

  - slug: coherentai-first-test
    path: canon-final/system-kernel/COHERENTAI_FIRST_TEST.md
    doc_class: test_spec
    binding_strength: medium
    pillar: coherentai
    related_pillar: measures
    status: active
    event_required: true

  - slug: structural-boundaries
    path: canon-final/system-kernel/STRUCTURAL_BOUNDRIES.md
    doc_class: architecture
    binding_strength: high
    pillar: coherentai
    status: active

  - slug: structural-boundaries-legacy
    path: canon-final/system-kernel/STRUCTURAL_BOUNDRIES_LEGACY.md
    doc_class: architecture
    binding_strength: low
    pillar: coherentai
    status: superseded

  - slug: c3-canon-decision-protocol
    path: canon-final/system-kernel/c3-canon-decision-protocol.md
    doc_class: protocol
    binding_strength: high
    pillar: coherentai
    status: active

  - slug: glyph-registry
    path: canon-final/system-kernel/GLYPH_REGISTRY.md
    doc_class: glyph_registry
    binding_strength: medium
    pillar: coherentai
    status: active

  - slug: coherentai-v1-spec
    path: canon-final/system-kernel/coherentai-v1-spec.md
    doc_class: architecture
    binding_strength: high
    pillar: coherentai
    status: active

  - slug: coherentai-v1-assessment-of-findings
    path: canon-final/system-kernel/assessment-of-findings-v1.0.md
    doc_class: assessment
    binding_strength: medium
    pillar: coherentai
    status: active

  - slug: full-system-flow
    path: canon-final/system-kernel/full-system-flow.md
    doc_class: architecture
    binding_strength: high
    pillar: coherentai
    status: active

  - slug: coherentai-system-kernel-index
    path: canon-final/system-kernel/system_kernel_index.md
    doc_class: registry
    binding_strength: high
    pillar: coherentai
    status: active

  - slug: role-contracts-index
    path: canon-final/system-kernel/role_contracts_index.md
    doc_class: registry
    binding_strength: high
    pillar: coherentai
    status: active

  - slug: measures-coherentai-installation-environment
    path: canon-final/system-kernel/measures_installation_environment.md
    doc_class: architecture
    binding_strength: high
    pillar: measures
    status: active

---

# SECTION 4 — Measures Kernel
bucket: codex-vault / folder: measures-kernel

  - slug: measures-data-contract
    path: canon-final/measures-kernel/MEASURES_DATA_CONTRACT.md
    doc_class: data_contract
    binding_strength: high
    pillar: measures
    status: draft

  - slug: measures-encounter-types
    path: canon-final/measures-kernel/MEASURES_ENCOUNTER_TYPES.md
    doc_class: encounter_model
    binding_strength: high
    pillar: measures
    status: active

  - slug: measures-gates-conversion-record
    path: canon-final/measures-kernel/MEASURES_GATES-CONVERSION_RECORD.md
    doc_class: conversion_record
    binding_strength: medium
    pillar: measures
    status: draft

  - slug: measures-installation-logic-map
    path: canon-final/measures-kernel/MEASURES_INSTALLATION_LOGIC_MAP.md
    doc_class: logic_map
    binding_strength: high
    pillar: measures
    status: active

  - slug: measures-installation-architecture
    path: canon-final/measures-kernel/MEASURES_INSTALLATION_MODEL.md
    doc_class: installation_model
    binding_strength: high
    pillar: measures
    status: draft
    note: Slug renamed from measures-installation-model to avoid collision with field canon.

  - slug: measures-progress-map
    path: canon-final/measures-kernel/MEASURES_PROGRESS_MAP.md
    doc_class: progress
    binding_strength: low
    pillar: measures
    status: active

  - slug: measures-text-taxonomy
    path: canon-final/measures-kernel/MEASURES_TEXT_TAXONOMY.md
    doc_class: taxonomy
    binding_strength: medium_high
    pillar: measures
    status: active

  - slug: gate-completion-checklist
    path: canon-final/measures-kernel/gate-completion-checklist.md
    doc_class: checklist
    binding_strength: medium
    pillar: measures
    status: active
    event_required: true

---

# SECTION 5 — Role Contracts
bucket: codex-vault / folder: role-contracts

  - slug: role-contract-architecture-steward
    path: canon-final/role-contracts/01_architecture_steward.md
    doc_class: role_contract
    binding_strength: high
    pillar: coherentai
    status: active

  - slug: role-contract-implementation-builder
    path: canon-final/role-contracts/02_implementation_builder.md
    doc_class: role_contract
    binding_strength: high
    pillar: coherentai
    status: active

  - slug: role-contract-coherence-validator
    path: canon-final/role-contracts/03_coherence_validator.md
    doc_class: role_contract
    binding_strength: high
    pillar: coherentai
    status: active

  - slug: role-contract-operations-weaver
    path: canon-final/role-contracts/04_operations_weaver.md
    doc_class: role_contract
    binding_strength: high
    pillar: coherentai
    status: active

  - slug: role-contract-canon-librarian
    path: canon-final/role-contracts/05_canon_librarian.md
    doc_class: role_contract
    binding_strength: high
    pillar: coherentai
    status: active

  - slug: role-contract-oar-router
    path: canon-final/role-contracts/06_oar_router.md
    doc_class: role_contract
    binding_strength: high
    pillar: coherentai
    status: active

  - slug: role-contract-field-curator
    path: canon-final/role-contracts/07_field_curator.md
    doc_class: role_contract
    binding_strength: high
    pillar: coherentai
    status: active

---

# SECTION 6 — OAR Logs
bucket: codex-vault / folder: oar-logs

  - slug: oar-measures-gates-conversion
    path: src/systems/coherentai/kernel/logs/OAR/OAR_MEASURES_GATES_CONVERSION_CANONICAL_INSTALLATION_PATH_ESTABLISHED.md
    doc_class: oar_log
    binding_strength: low
    pillar: measures
    status: sealed

---

# Registry Summary

total_documents: 52

by_folder:
  field-canon: 15
  pillar-canon: 11
  system-kernel: 23
  measures-kernel: 8
  role-contracts: 7
  oar-logs: 1

by_binding_strength:
  critical: 20
  high: 24
  medium_high: 1
  medium: 5
  low: 3

by_status:
  active: 44
  draft: 4
  superseded: 1
  sealed: 1
  event_required: 7
