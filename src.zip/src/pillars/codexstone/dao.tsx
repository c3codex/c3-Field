export default function RestorePage() { ... }

