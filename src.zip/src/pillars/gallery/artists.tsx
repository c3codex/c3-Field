export default function ArtistsPage() { ... }
